# bigdata-ingestion
Demo project: Big Data Ingestion + Credit-Regulated API System

## What's included
- Docker Compose stack: Postgres, ClickHouse, Redis, FastAPI service
- Ingestion script (PySpark skeleton) that reads CSV/JSON/Parquet and writes a unified parquet
- SQL schema for Postgres (users, credit_logs, api_logs)
- Docs: architecture, schema, API spec (markdown)
- Sample small dataset in /data/sample
- Sample outputs in /sample-output

## Quickstart (local)
1. Clone or unzip this repo.
2. Start services:
   ```
   docker-compose up -d
   ```
3. Initialize Postgres schema:
   ```
   psql "host=localhost user=demo password=demo dbname=demo" -f sql/schema.sql
   ```
   (or use Docker exec to run psql inside the container)
4. Seed a demo user:
   ```
   psql "host=localhost user=demo password=demo dbname=demo" -c "INSERT INTO users(username, api_key, credits, rate_limit_per_minute) VALUES ('alice','demo-key-123', 1000, 100);"
   ```
5. (Optional) Run ingestion (requires pyspark or use local python with pyspark installed):
   ```
   python src/ingestion/ingest_spark.py
   ```
6. Call API:
   ```
   curl -H "api_key: demo-key-123" "http://localhost:8000/v1/search?q=alice&limit=10"
   ```

## Notes
- This is a demo starter. For production, secure secrets, parameterize configs, and use managed services.
