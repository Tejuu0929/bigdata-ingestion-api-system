# Architecture - bigdata-ingestion (Demo)

Components:
- Raw data (CSV/JSON/Parquet) placed under /data/sample
- Ingestion: PySpark script reads files, normalizes, computes record_hash, writes unified parquet
- Storage: unified parquet in /sample-output (demo). In production: S3 + Delta Lake
- OLAP: ClickHouse (demo) for fast reads
- API: FastAPI service that queries ClickHouse and enforces credit-based access (Postgres stores users & credits)
- Caching: Redis used for simple rate-limiting in demo

Diagram (text):
[data files] -> [PySpark ingestion] -> [unified parquet] -> [ClickHouse] -> [FastAPI + Redis + Postgres] -> Clients
