# Schema - Master Dataset (example)

Example master schema (normalized):
- record_hash: string (primary dedupe key)
- source: string (original filename)
- ingestion_ts: timestamp
- name: string
- email: string
- phone: string
- attributes: json (optional fields)
