# API Spec (demo)

## Endpoint: GET /v1/search
Headers:
  - api_key: string (required)

Query params:
  - q: string (optional) - wildcard search across name/attributes
  - limit: int (optional, default 100)
  - offset: int (optional, default 0)

Response:
{
  "meta": {"count": <rows_returned>, "credits_used": <int>, "response_time_ms": <int>},
  "data": [ ... rows ... ]
}

Error codes:
  - 401: Invalid API key
  - 402: Insufficient Credits
  - 429: Rate limit exceeded
  - 500: Query error
