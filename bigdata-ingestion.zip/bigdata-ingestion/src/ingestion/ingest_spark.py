import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit, sha2, concat_ws, current_timestamp
import requests

INPUT_DIR = os.getenv("INPUT_DIR", "./data/sample")
OUT_DIR = os.getenv("OUT_DIR", "./sample-output")
CLICKHOUSE_HOST = os.getenv("CLICKHOUSE_HOST", "localhost")
CLICKHOUSE_HTTP_PORT = int(os.getenv("CLICKHOUSE_HTTP_PORT", 8123))

spark = SparkSession.builder.appName("demo-unify").getOrCreate()

def read_any(path):
    if path.endswith(".parquet"):
        return spark.read.parquet(path)
    if path.endswith(".json") or path.endswith(".jsonl"):
        return spark.read.json(path)
    if path.endswith(".csv"):
        return spark.read.option("header", "true").option("inferSchema", "true").csv(path)
    raise ValueError("Unsupported format: " + path)

def normalize(df, source):
    df2 = df.withColumn("source", lit(source)).withColumn("ingestion_ts", current_timestamp())
    cols = df2.columns[:3] if len(df2.columns) >= 3 else df2.columns
    if not cols:
        df2 = df2.withColumn("record_hash", sha2(lit("empty"), 256))
    else:
        df2 = df2.withColumn("record_hash", sha2(concat_ws("||", *cols), 256))
    return df2

def main():
    files = []
    for root, dirs, filelist in os.walk(INPUT_DIR):
        for f in filelist:
            if f.startswith("."):
                continue
            files.append(os.path.join(root, f))
    if not files:
        print("No input files found in", INPUT_DIR)
        return
    unified = None
    for p in files:
        print("Reading", p)
        df = read_any(p)
        dfn = normalize(df, os.path.basename(p))
        unified = dfn if unified is None else unified.unionByName(dfn, allowMissingColumns=True)
    os.makedirs(OUT_DIR, exist_ok=True)
    out_path = os.path.join(OUT_DIR, "unified.parquet")
    unified.write.mode("overwrite").parquet(out_path)
    print("Wrote unified parquet to", out_path)
    sample = unified.limit(100).toPandas()
    if not sample.empty:
        try:
            cols = list(sample.columns)
            rows = sample.values.tolist()
            csv_rows = []
            for row in rows:
                csv_rows.append("\t".join([str(x) if x is not None else "\\N" for x in row]))
            payload = "\n".join(csv_rows)
            url = f"http://{CLICKHOUSE_HOST}:{CLICKHOUSE_HTTP_PORT}/?query=INSERT%20INTO%20master_table%20FORMAT%20TSV"
            r = requests.post(url, data=payload.encode("utf-8"))
            print("ClickHouse insert:", r.status_code, r.text)
        except Exception as e:
            print("ClickHouse insert skipped (error):", e)

if __name__ == "__main__":
    main()
