import os
import time
import json
import asyncio
from fastapi import FastAPI, Header, HTTPException, Request
import asyncpg
from clickhouse_driver import Client as CHClient
import aioredis

PG_DSN = os.getenv("PG_DSN", "postgresql://demo:demo@postgres:5432/demo")
CLICKHOUSE_HOST = os.getenv("CLICKHOUSE_HOST", "clickhouse")
REDIS_HOST = os.getenv("REDIS_HOST", "redis")

app = FastAPI(title="Unified Data API - Demo")

db_pool = None
ch = None
redis = None

@app.on_event("startup")
async def startup():
    global db_pool, ch, redis
    db_pool = await asyncpg.create_pool(PG_DSN, min_size=1, max_size=5)
    ch = CHClient(host=CLICKHOUSE_HOST)
    redis = await aioredis.from_url(f"redis://{REDIS_HOST}:6379", encoding="utf-8", decode_responses=True)

async def get_user_by_apikey(apikey: str):
    async with db_pool.acquire() as conn:
        row = await conn.fetchrow("SELECT id, credits, rate_limit_per_minute FROM users WHERE api_key=$1", apikey)
        return row

async def deduct_credits_tx(user_id: int, cost: int):
    async with db_pool.acquire() as conn:
        async with conn.transaction():
            row = await conn.fetchrow("SELECT credits FROM users WHERE id=$1 FOR UPDATE", user_id)
            if row is None:
                return False
            if row['credits'] < cost:
                return False
            new = row['credits'] - cost
            await conn.execute("UPDATE users SET credits=$1 WHERE id=$2", new, user_id)
            await conn.execute(
                "INSERT INTO credit_logs(user_id, credits_before, credits_after, credits_delta, reason) VALUES ($1,$2,$3,$4,$5)",
                user_id, row['credits'], new, -cost, "api_call"
            )
            return True

async def log_api_call(user_id, endpoint, params, credits, duration_ms, status_code):
    async with db_pool.acquire() as conn:
        await conn.execute(
            "INSERT INTO api_logs(user_id, endpoint, params, credits_used, duration_ms, status_code) VALUES ($1,$2,$3,$4,$5,$6)",
            user_id, endpoint, json.dumps(params), credits, duration_ms, status_code
        )

def build_clickhouse_query(filters: dict, limit: int, offset: int):
    where_clauses = []
    vals = {}
    for k, v in filters.items():
        if k == "q":
            where_clauses.append(f"(name LIKE %(q)s OR attributes LIKE %(q)s)")
            vals["q"] = f"%{v}%"
        else:
            where_clauses.append(f"{k} = %({k})s")
            vals[k] = v
    where = " AND ".join(where_clauses) if where_clauses else "1=1"
    q = f"SELECT * FROM master_table WHERE {where} LIMIT %(limit)s OFFSET %(offset)s"
    vals["limit"] = limit
    vals["offset"] = offset
    return q, vals

@app.get("/v1/search")
async def search(request: Request, api_key: str = Header(...), q: str = None, limit: int = 100, offset: int = 0):
    t0 = time.time()
    user = await get_user_by_apikey(api_key)
    if not user:
        raise HTTPException(401, "Invalid API key")
    rl_key = f"rl:{user['id']}:{int(time.time()//60)}"
    cur = await redis.incr(rl_key)
    if cur == 1:
        await redis.expire(rl_key, 61)
    if cur > user['rate_limit_per_minute']:
        raise HTTPException(429, "Rate limit exceeded")

    cost = 1 + (limit // 100)
    ok = await deduct_credits_tx(user['id'], cost)
    if not ok:
        raise HTTPException(402, "Insufficient Credits")

    filters = {}
    if q:
        filters['q'] = q

    sql, params = build_clickhouse_query(filters, limit, offset)
    try:
        # WARNING: simplified for demo; do not format strings directly in production
        formatted = sql % params if params else sql
        rows = ch.execute(formatted)
    except Exception as e:
        duration_ms = int((time.time() - t0) * 1000)
        asyncio.create_task(log_api_call(user['id'], "/v1/search", {"q": q, "limit": limit, "offset": offset}, cost, duration_ms, 500))
        raise HTTPException(500, f"Query error: {e}")

    duration_ms = int((time.time() - t0) * 1000)
    asyncio.create_task(log_api_call(user['id'], "/v1/search", {"q": q, "limit": limit, "offset": offset}, cost, duration_ms, 200))
    return {"meta": {"count": len(rows), "credits_used": cost, "response_time_ms": duration_ms}, "data": rows}
