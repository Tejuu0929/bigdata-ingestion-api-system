CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  username TEXT UNIQUE,
  api_key TEXT UNIQUE,
  role TEXT DEFAULT 'user',
  credits BIGINT DEFAULT 0,
  rate_limit_per_minute INT DEFAULT 60,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS credit_logs (
  id SERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id),
  credits_before BIGINT,
  credits_after BIGINT,
  credits_delta BIGINT,
  reason TEXT,
  timestamp TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS api_logs (
  id SERIAL PRIMARY KEY,
  user_id INT,
  endpoint TEXT,
  params JSONB,
  credits_used BIGINT,
  duration_ms INT,
  status_code INT,
  timestamp TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS processed_files (
  id SERIAL PRIMARY KEY,
  file_path TEXT,
  checksum TEXT,
  processed_at TIMESTAMP DEFAULT now()
);
